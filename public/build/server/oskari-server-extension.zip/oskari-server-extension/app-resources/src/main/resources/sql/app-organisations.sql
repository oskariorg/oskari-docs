insert into oskari_layergroup(locale) values('{ "en":{ "name":"My organization"} }');
